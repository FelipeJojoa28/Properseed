<?php
include ("conexion.php");
$mysqli = new mysqli($host, $user, $pw, $db);

    $sql = "SELECT TRUNCATE(AVG(Humedad_suelo),2) as HUMS_PRO FROM Parametros WHERE Id_dispositivo = '1' AND Fecha >= '2020-07-30' AND Fecha <= '2020-11-25' GROUP BY HOUR(Hora) ORDER BY Hora";
	$hums = mysqli_query($mysqli,$sql);
	$hums = mysqli_fetch_all($hums,MYSQLI_ASSOC);
	$hums = json_encode(array_column($hums, 'HUMS_PRO'),JSON_NUMERIC_CHECK);
    $sql2 = "SELECT HOUR(Hora) as EjeX FROM Parametros WHERE Id_dispositivo = '1' AND Fecha >= '2020-07-30' AND Fecha <= '2020-11-25' GROUP BY HOUR(Hora) ORDER BY Hora";
	$ejex = mysqli_query($mysqli,$sql2);
	$ejex = mysqli_fetch_all($ejex,MYSQLI_ASSOC);
	$ejex = json_encode(array_column($ejex, 'EjeX'),JSON_NUMERIC_CHECK);
?>

<!DOCTYPE html>
<html>
<head>
	<title>HighChart</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.js"></script>
	<script src="https://code.highcharts.com/highcharts.js"></script>
</head>
<body>

<script type="text/javascript">

$(function () { 

    var data_hums = <?php echo $hums; ?>;
    var data_ejex = <?php echo $ejex; ?>;
    $('#container').highcharts({
        chart: {
            type: 'spline'
        },
        title: {
            text: 'Humedad del suelo por hora'
        },
        xAxis: {
            categories: data_ejex//['00','01','02','03','04','05','06','07','08','09','10','11','12','13','14','15','16','17','18','19','20','21','22','23']
        },
        yAxis: {
            title: {
                text: 'Humedad del suelo (%)'
            }
        },
        series: [{
            name: 'Humedad del suelo',
            data: data_hums
        }]
    });
});

</script>

<div class="container">
	<br/>
	<h2 class="text-center">Promedios de humedad del suelo</h2>
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading">Dashboard</div>
                <div class="panel-body">
                    <div id="container"></div>
                </div>
            </div>
        </div>
    </div>
</div>

</body>
</html>      