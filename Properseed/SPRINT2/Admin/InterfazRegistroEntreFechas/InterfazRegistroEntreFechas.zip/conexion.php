<?php
$host = "localhost";
$user = "id14907127_admin";
$pw = "Properseed-lab3";
$db = "id14907127_sistema_properseed";
?>